Name: 
Chirag Mandan
Email: 
chirag.mandan@lexisnexis.com

DataSource:
Bureau of Transportation Statistics
(On-Time performance statistics of the Airlines for February 2011)

Download the data:

1. Go to http://www.transtats.bts.gov/DL_SelectFields.asp?Table_ID=236&DB_Short_Name=On-Time
2. Select the following fields on the webpage:

DayOfMonth	
FlightDate
UniqueCarrier
AirlineID
FlightNumber
Origin
OriginStateName
Destination
DestStateName
SchedDepTime
ActualDepTime
DepDelay
SchedArrTime
ActualArrTime
ArrDelay
IndCancelled
IndDiverted
SchedElapsedTime
ActualElapsedTime
AirTime
NumFlights
Distance
CarrierDelay
WeatherDelay
NASDelay
SecurityDelay
LateAircraftDelay

 
3. Click the "download" button. 
4. Also download the lookuptable for Unique Carrier. To do this, click on "Get Lookup Table" link beside "Unique Carrier"
  


Process and explanation of the ECL code:

1.  Transfer the downloaded files to the landing zone on the VM (/var/lib/LexisNexis/mydropzone)
2.  Spray the CSV files using ECL Watch (~data::crm::performance should be the logical file name for the flight data 
    and ~data::crm::carrierlookup for the lookup table)
3.  Create a repository called "airline_performance_monitor" within Samples repo in ECL IDE. Import all the ECL files included in the submission under airline_performance_monitor folder to airline_performance_monitor repository
4.  Record Layouts are created for each of the sprayed files (Layout_AirlineInfo.ecl, Layout_CarrierLookup.ecl). 
5.  Datasets are created for each of the sprayed files (File_FlightInfo.ecl, File_CarrierLookup.ecl)
6.  Run BWR_FlightInfo to get information about the data
7.  Clean_CarrierLookup and Clean_FlightInfo are used to clean-up the input data - removing the quotes around the data
8.  Process Data. This involves a new Layout with additional attributes to calculate the cause of the delay(Layout_FlightData) 
    and a BWR to Join AirlineInfo and CarrierLookup
9.  Run JoinFlightData in a builder window to process data. The output is written to a file with the logical name:~data::crm::flightdata
10. File_FlightData is used to create the dataset with virtual fileposition from the output file mentioned in #9 
11. IDX_FlightsByDate and IDX_FlightsByAirport are used to create index files for the query
12. Run BWR_BuildFlightsByAirportIndex and BWR_BuildFlightsByDateIndex in the builder window to build indices. This BWR uses the IDX files above 
    to actually build the indices.


Testing:
I've Tested all of my code using the VM available on HPCC Website (http://www.hpccsystems.com)


Steps to run One Query:

1. As mentioned above, download the data
2. Transfer the downloaded files to the landing zone on the VM. Please use the instructions above
3. Use ECL Watch to spray the files. Please see the instructions above
4. Create a repository called "airline_performance_monitor" within Samples repository in ECL IDE. Import all the ECL files included in the submission 
   under airline_performance_monitor folder to airline_performance_monitor repository
5. Run BWR_FlightInfo to get information about the data (Please make sure the target is set to "thor")
6. Run JoinFlightData in a builder window
7. Run BWR_BuildFlightsByDateIndex in the builder window to build the index
8. Run FetchDelayedFlightsByDate in the builder window to examine the results of the query in ECL IDE
9. Run FetchDelayedFlightsByDateService in the builder window. Once completed, go to ECLWatch tab and click on Publish button. You should see 
   workunit published dialog box.
10.Now to to http://<ESP IP>:8002, click on +Thor and click on "FetchDelayedFlightsByDate".
11.In the DayValue, type 5
12.Click Submit.
13.The results are available immediately on the same webpage in XML format.


For any further questions, please contact Chirag Mandan at chirag.mandan@lexisnexis.com

Thank you!
-Chirag