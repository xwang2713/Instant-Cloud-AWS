from djutils.utils.helpers import generic_autodiscover


def autodiscover():
    return generic_autodiscover('commands')
