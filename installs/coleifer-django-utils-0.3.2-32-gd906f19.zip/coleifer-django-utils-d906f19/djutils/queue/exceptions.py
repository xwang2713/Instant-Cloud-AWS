class QueueException(Exception):
    pass
