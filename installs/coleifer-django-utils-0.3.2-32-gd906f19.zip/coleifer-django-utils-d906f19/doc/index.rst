.. django-utils documentation master file, created by
   sphinx-quickstart on Sat Mar 19 12:43:51 2011.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to django-utils's documentation!
========================================

a collection of tools for django projects

Contents:

.. toctree::
   :maxdepth: 2
   :glob:
   
   django-utils/getting_started
   django-utils/cache
   django-utils/daemon
   django-utils/dashboard/index
   django-utils/db
   django-utils/decorators
   django-utils/middleware
   django-utils/queue
   django-utils/templatetags
   django-utils/test
   django-utils/utils/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

