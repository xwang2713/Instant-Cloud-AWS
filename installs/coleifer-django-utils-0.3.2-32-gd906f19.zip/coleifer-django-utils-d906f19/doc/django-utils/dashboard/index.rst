Dashboard
=========

A plugin-based app similar to munin.  App collects data every minute, which is
displayed in a live-updating dashboard, along with hourly aggregates.

Contents:

.. toctree::
   :maxdepth: 2
   :glob:
   
   installation
   panels
   registry

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

