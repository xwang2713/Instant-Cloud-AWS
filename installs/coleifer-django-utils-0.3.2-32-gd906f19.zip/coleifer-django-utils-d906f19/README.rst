============
django-utils
============

a collection of tools to help with django development

view documentation:

http://charlesleifer.com/docs/djutils/
